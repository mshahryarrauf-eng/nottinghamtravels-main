import mongoose from "mongoose";

const segmentSchema = new mongoose.Schema({
  departureAirport: String,
  arrivalAirport: String,
  departureTime: Date,
  arrivalTime: Date,
  airline: String,
  flightNumber: String,
  bookingClass: String,
});

const itinerarySchema = new mongoose.Schema({
  duration: String,
  segments: [segmentSchema],
});

const passengerSchema = new mongoose.Schema({
  type: String, // ADT / CNN / INF
  firstName: String,
  lastName: String,
  gender: String,
  dob: Date,
  passportNumber: String,
  passportExpiry: Date,
  nationality: String,
});

const flightBookingSchema = new mongoose.Schema(
  {
    contact: {
      email: String,
      phone: String,
    },

    passengers: [passengerSchema],

    itineraries: [itinerarySchema],

    pricing: {
      baseFare: Number,
      taxes: Number,
      total: Number,
      currency: String,
    },

    sabreOfferId: String,

    pnr: String,
    tickets: [String],

    status: {
      type: String,
      enum: ["pending", "succeeded", "failed"],
      default: "pending",
    },
  },
  { timestamps: true }
);

export default mongoose.models.FlightBooking ||
  mongoose.model("FlightBooking", flightBookingSchema);